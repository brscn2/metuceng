import java.util.ArrayList;

public class CengTree {
    public CengTreeNode root;
    // Any extra attributes...

    public CengTree(Integer order) {
        CengTreeNode.order = order;
        // TODO: Initialize the class
        root = new CengTreeNodeLeaf(null);
        root.type = CengNodeType.Leaf;
    }

    public void addBook(CengBook book) {
        // TODO: Insert Book to Tree
        Integer searchKey = book.getBookID();

        CengTreeNode currentNode = root;
        while (currentNode.getType() != CengNodeType.Leaf) {
            currentNode = ((CengTreeNodeInternal) currentNode).getChildNode(searchKey);
        }

        CengTreeNodeInternal newRoot = ((CengTreeNodeLeaf) currentNode).addBookToLeaf(book);
        root = newRoot == null ? root : newRoot;
    }

    public ArrayList<CengTreeNode> searchBook(Integer bookID) {
        // TODO: Search within whole Tree, return visited nodes.
        // Return null if not found.
        ArrayList<CengTreeNode> visitedNodes = new ArrayList<>();

        CengTreeNode currentNode = root;
        int tabCount = 0;
        while (currentNode.getType() != CengNodeType.Leaf) {
            //System.out.println("Visited node: " + currentNode.getNodeKey());
            visitedNodes.add(currentNode);
            ((CengTreeNodeInternal) currentNode).searchPrintNode(tabCount++);
            currentNode = ((CengTreeNodeInternal) currentNode).getChildNode(bookID);
        }
        visitedNodes.add(currentNode);  // Add the leaf node
        ((CengTreeNodeLeaf) currentNode).searchPrintNode(tabCount, bookID);
        //System.out.println("At leaf node: " + currentNode.getNodeKey());

        if (((CengTreeNodeLeaf) currentNode).containsBook(bookID)) {
            //System.out.println("Book exists.");
            return visitedNodes;
        }

        return null;
    }

    public void printTree() {
        // TODO: Print the whole tree to console
        root.printNode(0);
    }

    // Any extra functions...
}
